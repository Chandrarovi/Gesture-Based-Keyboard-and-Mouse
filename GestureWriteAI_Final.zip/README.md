# GestureWriteAI — Hand Gesture Controlled Keyboard & Mouse

## Overview
GestureWriteAI is a real-time hand gesture recognition system that allows users to control the mouse and keyboard through hand movements. Using OpenCV, MediaPipe, PyAutoGUI, and a CNN trained on EMNIST, it provides a seamless “air-writing” experience — moving the cursor, drawing characters in mid-air, and typing them automatically wherever the text cursor is focused.

## ✨ Features
| Feature | Description |
|----------|-------------|
| 🖱️ Gesture-based Mouse Control | Move the on-screen cursor using your hand position. |
| ✋ Single User Tracking | Locks input to one detected hand (first recognized user). |
| ✍️ Air-Writing Recognition | Draw letters in the air; CNN identifies them and types automatically. |
| ⌨️ Simulated Keyboard Input | Recognized characters are typed directly into any active text box using PyAutoGUI. |
| 🔁 Mode Switching via Gestures | Switch between modes:<br>✋ Palm → Mouse mode<br>☝️ Index finger → Writing mode<br>✊ Fist → Clear canvas<br>✌️ Two fingers → Backspace<br>🤞 Gesture → Space |
| 🧠 CNN Model Trained on EMNIST | Model recognizes hand-drawn letters and digits. |
| 🧍 Single Person Focus | The system identifies and tracks only one person’s hand gestures. |

## 🧩 Technology Stack
- Python 3.8+
- OpenCV — image capture & drawing
- MediaPipe — real-time hand tracking
- NumPy — coordinate normalization & data preprocessing
- PyAutoGUI — simulating keyboard/mouse events
- TensorFlow / Keras — CNN model for character recognition
- CVZone (optional) — simplifies gesture tracking overlays

## 🧠 How It Works
1. Detects and tracks hand landmarks using MediaPipe.
2. Normalizes fingertip coordinates to map movements on-screen.
3. Captures motion trajectory (drawing mode).
4. Sends the drawn image to CNN → predicts letter.
5. Uses PyAutoGUI to type predicted character in focused window.
6. Uses predefined gestures to switch between control modes.

## ⚙️ Project Structure
```
GestureWriteAI/
│
├── main.py                # Entry point; runs both mouse & keyboard control
├── hand_tracker.py        # Handles hand detection using MediaPipe
├── gesture_controller.py  # Logic for cursor movement, gesture switching
├── air_write.py           # Captures air-writing strokes and saves to canvas
├── cnn_model.py           # CNN architecture & EMNIST training
├── predictor.py           # Loads trained CNN and predicts letters
├── requirements.txt       # Dependencies
└── README.md              # Full project documentation
```

## 🧪 Setup Instructions
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the main app:
   ```bash
   python main.py
   ```
3. Hold your hand in front of the webcam:
   - Open palm → move cursor
   - Raise index finger → write
   - Fist → clear canvas
   - Two fingers → backspace
   - Crossed fingers → space

## 🚀 Future Enhancements
- Add gesture calibration for different users
- Extend CNN to recognize entire words
- Implement predictive text
- Integrate voice feedback for recognized letters
